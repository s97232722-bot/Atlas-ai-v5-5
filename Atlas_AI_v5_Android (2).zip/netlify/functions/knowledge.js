const { getStore } = require("@netlify/blobs");
exports.handler = async function (event) {
  const headers = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" };
  if (event.httpMethod !== "GET") return { statusCode: 405, headers, body: JSON.stringify({ error: "Разрешён только GET." }) };
  try {
    const store = getStore("atlas-knowledge");
    const items = await store.get("scheduled-research", { type: "json" }) || [];
    const lastRun = await store.get("last-run", { type: "json" }) || null;
    const runs = await store.get("run-history", { type: "json" }) || [];
    return { statusCode: 200, headers, body: JSON.stringify({ items, lastRun, runs: Array.isArray(runs) ? runs.slice(0, 30) : [] }) };
  } catch (_) {
    return { statusCode: 200, headers, body: JSON.stringify({ items: [], lastRun: null, note: "База знаний пока пуста или хранилище ещё не инициализировано." }) };
  }
};
