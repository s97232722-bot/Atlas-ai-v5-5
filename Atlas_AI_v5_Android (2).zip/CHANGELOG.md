# Изменения

## v5.0.0
- Плановый исследователь переведён на циклы каждые 8 часов.
- Добавлен самостоятельный выбор тем из учебной программы с ограничением до двух тем за цикл и шести тем за UTC-сутки.
- Добавлен учёт циклов, лимита и статуса выполнения.
- Добавлена браузерная лаборатория для обучения маленького классификатора текста методом наивного Байеса.
- Обновлены инструкция по публикации и описание границ самообучения.

## v4
- Базовые ограничения запросов, проверка источника запроса, защита от повторного запуска и история исследований.

## v5.1 — Android-friendly chat interface
- Added installable PWA metadata and app icon for Android home-screen use.
- Added local conversation history (up to 60 chats) and quick chat switching.
- Added a service worker to cache the app shell; chat/API calls still require an internet connection and a deployed backend.
- Improved mobile header actions and install guidance.
